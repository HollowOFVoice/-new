<?php
// Подключение к базе данных
$host = 'localhost';
$db = 'guestbook';
$user = 'root';
$pass = '';

$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Обработка отправки формы
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $msg = htmlspecialchars($_POST['message']);

    // Сохранение сообщения в базе данных
    $stmt = $pdo->prepare("INSERT INTO messages (name, message) VALUES (?, ?)");
    $stmt->execute([$name, $msg]);

    $message = "Сообщение успешно сохранено!";
}

// Пагинация
$limit = 5; // Количество сообщений на странице
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Получение всех сообщений с пагинацией
$stmt = $pdo->prepare("SELECT * FROM messages ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Получение общего количества сообщений
$totalStmt = $pdo->query("SELECT COUNT(*) FROM messages");
$totalMessages = $totalStmt->fetchColumn();
$totalPages = ceil($totalMessages / $limit);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Гостевая книга</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Гостевая книга</h1>

<?php if ($message): ?>
    <p><?php echo $message; ?></p>
<?php endif; ?>

<form method="POST">
    <label for="name">Имя:</label>
    <input type="text" name="name" required>
    <br>
    <label for="message">Сообщение:</label>
    <textarea name="message" required></textarea>
    <br>
    <button type="submit">Отправить</button>
</form>

<h2>Сообщения:</h2>
<ul>
    <?php foreach ($messages as $msg): ?>
        <li>
            <strong><?php echo htmlspecialchars($msg['name']); ?></strong>: <?php echo htmlspecialchars($msg['message']); ?>
            <br>
            <small><?php echo $msg['created_at']; ?></small>
        </li>
    <?php endforeach; ?>
</ul>

<div>
    <h3>Пагинация:</h3>
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>
</div>
</body>
</html>
